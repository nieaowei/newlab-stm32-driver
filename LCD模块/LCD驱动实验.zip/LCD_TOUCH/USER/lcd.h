/***************************************************************
  *	Name		:	LCD.H
  *	Data		:	2019.7.31
  *	Author	:	NIEAOWEI
  *	Note		:	LCD��ز�������
****************************************************************/
#ifndef _LCD_H
#define _LCD_H


void LCD_Init(void);
void LCD_Demo(void);
#endif

